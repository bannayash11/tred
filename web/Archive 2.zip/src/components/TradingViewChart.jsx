import React, { useEffect, useRef, useState } from 'react';

const INDEX_MAP = {
  'NIFTY 50': 'NSE:NIFTY',
  NIFTY: 'NSE:NIFTY',
  BANKNIFTY: 'NSE:BANKNIFTY',
  FINNIFTY: 'NSE:FINNIFTY',
  MIDCPNIFTY: 'NSE:MIDCPNIFTY',
  SENSEX: 'BSE:SENSEX'
};

const INTERVAL_MAP = {
  '1m': '1',
  '3m': '3',
  '5m': '5',
  '15m': '15',
  '1h': '60',
  '1d': 'D'
};

/** Map app symbol → TradingView EXCHANGE:SYMBOL */
export function toTradingViewSymbol(symbol) {
  const raw = String(symbol || '').trim().toUpperCase();
  if (!raw) return 'NSE:NIFTY';
  if (INDEX_MAP[raw]) return INDEX_MAP[raw];
  if (raw.includes(':')) return raw;
  return `NSE:${raw.replace(/\s+/g, '')}`;
}

export function toTradingViewInterval(timeframe) {
  return INTERVAL_MAP[timeframe] || '5';
}

function useIsNarrow(breakpoint = 768) {
  const [narrow, setNarrow] = useState(() =>
    typeof window !== 'undefined' ? window.matchMedia(`(max-width: ${breakpoint}px)`).matches : false
  );

  useEffect(() => {
    const mq = window.matchMedia(`(max-width: ${breakpoint}px)`);
    const onChange = () => setNarrow(mq.matches);
    onChange();
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, [breakpoint]);

  return narrow;
}

/**
 * Free TradingView Advanced Chart embed (their market data + branding).
 * Mobile: explicit pixel height + side toolbar hidden so the iframe lays out correctly.
 */
export default function TradingViewChart({
  symbol,
  timeframe = '5m',
  className = ''
}) {
  const containerRef = useRef(null);
  const tvSymbol = toTradingViewSymbol(symbol);
  const interval = toTradingViewInterval(timeframe);
  const isNarrow = useIsNarrow(768);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return undefined;

    el.innerHTML = '';

    const applySize = () => {
      const parent = el.parentElement;
      const w = Math.max(
        1,
        Math.floor(el.clientWidth || parent?.clientWidth || el.offsetWidth || 0)
      );
      const h = Math.max(
        280,
        Math.floor(el.clientHeight || parent?.clientHeight || el.offsetHeight || 0)
      );

      const widget = el.querySelector('.tradingview-widget-container__widget');
      if (widget) {
        widget.style.width = '100%';
        widget.style.height = `${h}px`;
      }

      const iframe = el.querySelector('iframe');
      if (iframe) {
        iframe.style.width = '100%';
        iframe.style.height = `${h}px`;
        iframe.style.border = '0';
        iframe.setAttribute('width', String(w));
        iframe.setAttribute('height', String(h));
      }
    };

    const widgetHost = document.createElement('div');
    widgetHost.className = 'tradingview-widget-container__widget';
    widgetHost.style.width = '100%';
    widgetHost.style.height = '100%';
    el.appendChild(widgetHost);

    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
    script.type = 'text/javascript';
    script.async = true;
    script.innerHTML = JSON.stringify({
      autosize: true,
      width: '100%',
      height: '100%',
      symbol: tvSymbol,
      interval,
      timezone: 'Asia/Kolkata',
      theme: 'dark',
      style: '1',
      locale: 'en',
      backgroundColor: '#090d16',
      gridColor: 'rgba(148, 163, 184, 0.08)',
      hide_top_toolbar: false,
      hide_side_toolbar: isNarrow,
      hide_legend: isNarrow,
      allow_symbol_change: false,
      save_image: false,
      calendar: false,
      withdateranges: !isNarrow,
      support_host: 'https://www.tradingview.com',
      studies: [],
      isTransparent: false
    });
    el.appendChild(script);

    applySize();

    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(applySize) : null;
    ro?.observe(el);

    // TradingView injects iframe async — keep sizing until it settles
    const poll = window.setInterval(applySize, 400);
    const stopPoll = window.setTimeout(() => window.clearInterval(poll), 8000);

    window.addEventListener('orientationchange', applySize);
    window.addEventListener('resize', applySize);

    return () => {
      ro?.disconnect();
      window.clearInterval(poll);
      window.clearTimeout(stopPoll);
      window.removeEventListener('orientationchange', applySize);
      window.removeEventListener('resize', applySize);
      el.innerHTML = '';
    };
  }, [tvSymbol, interval, isNarrow]);

  return (
    <div
      className={`relative w-full overflow-hidden ${className}`}
      style={{
        // Explicit box so TV autosize never collapses on mobile flex layouts
        height: isNarrow ? 'min(68dvh, 560px)' : '100%',
        minHeight: isNarrow ? 320 : 480
      }}
    >
      <div
        ref={containerRef}
        className="tradingview-widget-container absolute inset-0 overflow-hidden rounded-lg border border-slate-800/70 [&_iframe]:block [&_iframe]:max-w-full"
        style={{ width: '100%', height: '100%' }}
        title={tvSymbol}
      />
    </div>
  );
}
